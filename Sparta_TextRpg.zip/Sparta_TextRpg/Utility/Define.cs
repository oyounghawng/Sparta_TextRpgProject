﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sparta_TextRpg
{
    public enum SceneName
    {
        LoginScene,
        SelectCharScene,
        StartScene,
        StatusScene,
        BattleScene,
        Null,
    }
}

