﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sparta_TextRpg
{
    internal class StoreScene : BaseScene
    {
        public override void Enter()
        { 

        }

        public override void Excute()
        {

        }

        public override void ViewMenu()
        {

        }
    }
}
